import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'dart:math';

import '../models/vocabulary_model.dart';

class VocabularyService {
  final FlutterTts _tts = FlutterTts();

  VocabularyService() {
    _initTts();
  }

  Future<void> _initTts() async {
    await _tts.setLanguage('en-US');
    await _tts.setSpeechRate(0.5);
    await _tts.setVolume(1.0);
    await _tts.setPitch(1.0);
  }

  Stream<List<VocabularyTopic>> fetchTopics() {
    return FirebaseFirestore.instance
        .collection('vocabs_topics')
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) => VocabularyTopic.fromDoc(doc)).toList());
  }

  Future<List<VocabWord>> fetchWords(String topicId) async {
    final snapshot = await FirebaseFirestore.instance
        .collection('vocabs_topics')
        .doc(topicId)
        .collection('words')
        .get();
    return snapshot.docs.map((doc) => VocabWord.fromMap(doc.id, doc.data())).toList();
  }

  Future<List<Map<String, dynamic>>> loadQuiz(String topicId) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return [];

    final wordsSnap = await FirebaseFirestore.instance
        .collection('vocabs_topics')
        .doc(topicId)
        .collection('words')
        .get();

    final resultsSnap = await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('learningProgress')
        .doc('vocabulary')
        .collection(topicId)
        .doc('summary')
        .collection('quizResults')
        .get();

    final totalQuestions = wordsSnap.docs.fold(0, (sum, doc) {
      final exercises = doc.data()['exercises'] as Map<String, dynamic>? ?? {};
      return sum + exercises.length;
    });

    final Map<String, String> quizStatuses = {
      for (final doc in resultsSnap.docs) doc.id: doc['status'] as String
    };

    final List<Map<String, dynamic>> allExercises = [];
    const supportedTypes = ['multiple_choice', 'listening_choice', 'vocab_reorder', 'typing'];

    for (final wordDoc in wordsSnap.docs) {
      final wordId = wordDoc.id;
      final data = wordDoc.data();
      final exercises = data['exercises'] as Map<String, dynamic>? ?? {};

      for (final entry in exercises.entries) {
        final type = entry.value['type'];
        if (supportedTypes.contains(type)) {
          final quizKey = entry.key;
          final quizId = '${wordId}_$quizKey';
          final status = quizStatuses[quizId];

          allExercises.add({
            'wordId': wordId,
            'type': type,
            'key': quizKey,
            'data': entry.value,
            'status': status,
          });
        }
      }
    }

    final pendingOrWrong = allExercises.where((e) => e['status'] != 'correct').toList();
    final correct = allExercises.where((e) => e['status'] == 'correct').toList();

    pendingOrWrong.shuffle(Random());
    correct.shuffle(Random());

    return [...pendingOrWrong, ...correct].take(15).toList();
  }

  Future<void> saveQuizResult({
    required String topicId,
    required String wordId,
    required String quizKey,
    required String type,
    required String status,
  }) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    final quizId = '${wordId}_$quizKey';
    final docRef = FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('learningProgress')
        .doc('vocabulary')
        .collection(topicId)
        .doc('summary')
        .collection('quizResults')
        .doc(quizId);

    await docRef.set({
      'word': wordId,
      'type': type,
      'status': status,
      'updatedAt': FieldValue.serverTimestamp(),
      'attemptCount': FieldValue.increment(1),
      'lastAttemptTime': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Future<void> updateTopicProgress(String topicId, String topicTitle, int totalQuestions, int completedQuestions, int correctQuestions) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    final accuracy = completedQuestions > 0 ? correctQuestions / completedQuestions : 0;
    final completionRate = totalQuestions > 0 ? completedQuestions / totalQuestions : 0;

    await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('learningProgress')
        .doc('vocabulary')
        .collection(topicId)
        .doc('summary')
        .set({
      'topicId': topicId,
      'topicTitle': topicTitle,
      'totalQuestions': totalQuestions,
      'completedQuestions': completedQuestions,
      'correctQuestions': correctQuestions,
      'accuracy': accuracy,
      'completionRate': completionRate,
      'lastUpdated': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));

    final vocabSummarySnap = await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('learningProgress')
        .doc('vocabulary')
        .get();

    final vocabSummaryData = vocabSummarySnap.data();
    final List<dynamic> currentTopics = vocabSummaryData?['summary']?['topics'] ?? [];
    if (!currentTopics.contains(topicId)) {
      currentTopics.add(topicId);
      await FirebaseFirestore.instance
          .collection('users')
          .doc(uid)
          .collection('learningProgress')
          .doc('vocabulary')
          .set({
        'summary': {
          'topics': currentTopics,
          'lastUpdated': FieldValue.serverTimestamp(),
        }
      }, SetOptions(merge: true));
    }
  }

  Future<void> updateOverallProgress(String uid) async {
    int totalQuestions = 0;
    int totalCorrectQuestions = 0;
    int totalCompletedQuestions = 0;
    int totalTopics = 0;
    Map<String, int> allTopicsQuestions = {};

    final allTopicsSnap = await FirebaseFirestore.instance.collection('vocabs_topics').get();

    for (var topicDoc in allTopicsSnap.docs) {
      String topicId = topicDoc.id;
      final wordsSnap = await FirebaseFirestore.instance
          .collection('vocabs_topics')
          .doc(topicId)
          .collection('words')
          .get();

      int topicQuestions = 0;
      for (var wordDoc in wordsSnap.docs) {
        final exercises = wordDoc.data()['exercises'] as Map<String, dynamic>? ?? {};
        topicQuestions += exercises.length;
      }

      allTopicsQuestions[topicId] = topicQuestions;
      totalQuestions += topicQuestions;
      totalTopics++;
    }

    final vocabSummarySnap = await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('learningProgress')
        .doc('vocabulary')
        .get();

    final vocabSummaryData = vocabSummarySnap.data();
    final List<dynamic> userTopics = vocabSummaryData?['summary']?['topics'] ?? [];

    for (String topicId in userTopics) {
      final topicSnap = await FirebaseFirestore.instance
          .collection('users')
          .doc(uid)
          .collection('learningProgress')
          .doc('vocabulary')
          .collection(topicId)
          .doc('summary')
          .get();

      if (topicSnap.exists) {
        final data = topicSnap.data() as Map<String, dynamic>;
        totalCorrectQuestions += (data['correctQuestions'] as int? ?? 0);
        totalCompletedQuestions += (data['completedQuestions'] as int? ?? 0);
      }
    }

    final overallAccuracy = totalCompletedQuestions > 0 ? totalCorrectQuestions / totalCompletedQuestions : 0;

    await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('learningProgress')
        .doc('vocabulary')
        .set({
      'summary': {
        'totalTopics': totalTopics,
        'totalQuestions': totalQuestions,
        'totalCorrectQuestions': totalCorrectQuestions,
        'totalCompletedQuestions': totalCompletedQuestions,
        'overallAccuracy': overallAccuracy,
        'topics': userTopics,
        'topicsQuestions': allTopicsQuestions,
        'lastUpdated': FieldValue.serverTimestamp(),
      }
    }, SetOptions(merge: true));
  }

  Future<void> speak(String text) async {
    if (text.isNotEmpty) {
      await _tts.setLanguage("en-US");
      await _tts.setSpeechRate(0.4);
      await _tts.setPitch(1.0);
      await _tts.speak(text);
    }
  }

  void dispose() {
    _tts.stop();
  }
}